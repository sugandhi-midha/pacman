# cordman
A funny pacman-like javascript game, available under http://corda.games where nicknames of each ghost are blockchain terms.

<p align="center">
  <img src="https://github.com/corda/cordman/blob/master/img/preview.png" alt="cordman">
</p>
